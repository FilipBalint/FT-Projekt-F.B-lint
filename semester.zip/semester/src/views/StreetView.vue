<template>
    <main>
      <div >
        <Street/>
      </div>
    </main>
  </template>
  
  <script setup>
  import Street from '@/components/Street.vue'
  </script>
  