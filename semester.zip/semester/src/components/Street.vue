<template>
    <div class="uvod">
        <h1 class="nadpis">Street Culture</h1>
        <p>Street culture predstavuje dynamickú a viacvrstvovú komunitu, ktorá zahŕňa rôzne aspekty života a umenia. Obehní sa okolo hudby, oblečenia, jazyka a vizuálnych prejavov, 
            ktoré vytvárajú jedinečnú identitu a štýl pre ľudí, ktorí sa považujú za súčasť tejto kultúry. Tu sú niektoré z hlavných aspektov street culture:</p>
        <h2>Hudba</h2>    
        <article>
            <p>1. Hip-Hop: Je jedným z kľúčových prvkov street culture a zohráva centrálnu úlohu. Hip-hop hudba sa vyvinula v šesťdesiatych a sedemdesiatych rokoch 
                v New Yorku a stala sa základným kameňom pre street kultúru. 
                Rapy, DJing, breakdance a graffiti sú všetko súčasti hip-hopu.</p>
            <p>2. R&B, Soul, a ďalšie žánre: Okrem hip-hopu sa street culture inšpiruje aj inými hudobnými žánrami, 
                vrátane R&B a soulu. Tieto žánre pridávajú ďalšiu dimenziu k hudobnému štýlu street culture.</p>

        </article>

        <h2>Oblečenie</h2>

        <article>
            <p>1. Streetwear: Oblečenie je kľúčovým prejavom street culture. Streetwear kombinuje pohodlie s výrazným dizajnom a často zahŕňa ikonické kúsky ako sneakers, 
                mikiny, baseballové čiapky a denim. Značky ako Supreme, Off-White a Nike sú výraznými hráčmi v streetwear komunite.</p>
            <p>2. Express Yourself: Oblečenie v street culture slúži ako forma sebavyjadrenia a individuálneho vyjadrenia. 
                Jednotlivci často mixujú rôzne štýly a značky, aby vytvorili svoj vlastný unikátny vzhľad.</p>

        </article>
        <h2>Umenie</h2>

        <article>
            <p>Express Yourself: Oblečenie v street culture slúži ako forma sebavyjadrenia a individuálneho vyjadrenia. 
                Jednotlivci často mixujú rôzne štýly a značky, aby vytvorili svoj vlastný unikátny vzhľad.</p>
            <p>Street Art: Okrem graffiti patrí sem aj širšie pochopené street art, ktoré môže zahŕňať inštalácie, muraly a rôzne formy umeleckého vyjadrenia.</p>

        </article>

        <article>
            <p>Street culture je neustálo sa vyvíjajúcim a inovatívnym fenoménom, ktorý si zachováva svoju autenticitu a silný vplyv na globálnu popkultúru. 
                Je to miesto, kde sa ľudia stretávajú, vytvárajú, inšpirujú a vyjadrujú svoju jedinečnú individualitu.</p>
            
            </article>

      
    </div>
</template>
  
<script>
</script>
  
<style scoped>
p{
    font-size: 20px;
 
}
.uvod {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    flex-direction: column;
}


.nadpis {
    text-align: center;
    padding: 20px;
    margin: 10px;
    font-size: 35px;
}

.uvod h2 {
    text-align: center;
    padding: 10px;
    font-size: 25px;



}

.uvod p {
    margin: 10px;

}

.uvod span {
    font-weight: bolder;
}

.uvod article {
    font-size: 17px;
    max-width: 1000px;
}
</style>
  