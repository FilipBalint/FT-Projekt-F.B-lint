<template>
    <div class="paticka">
        <p> Filip Bálint © </p>
    </div>
    </template>
      
    <script>
    
    </script>
      
    <style scoped>
    .paticka{
    background-color: #0327c9;
        color: white;
    }
    p{
        text-align: center;
        margin-top: 40px;
    }
    </style>
      